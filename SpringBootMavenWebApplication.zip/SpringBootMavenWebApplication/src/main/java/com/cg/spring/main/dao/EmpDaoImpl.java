package com.cg.spring.main.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.main.model.Employee;

@Repository
public class EmpDaoImpl implements EmpDao {

	static List<Employee> list = new ArrayList<>();

	static {
		list.add(new Employee("pavan", 34567));
		list.add(new Employee("shanthi", 43123));
	}

	@Override
	public boolean check(Employee employee) {

		boolean flag = false;

		for (Employee employee2 : list) {

			if (employee2.getName().equals(employee.getName())) {

				flag = true;
				break;

			} else {
				flag = false;
			}
		}

		return flag;

	}

}
