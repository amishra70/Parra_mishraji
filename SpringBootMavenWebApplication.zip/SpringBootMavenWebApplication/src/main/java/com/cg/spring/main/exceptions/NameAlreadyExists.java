package com.cg.spring.main.exceptions;

public class NameAlreadyExists extends Exception {

	public NameAlreadyExists(String s) {
		super(s);
	}
}
