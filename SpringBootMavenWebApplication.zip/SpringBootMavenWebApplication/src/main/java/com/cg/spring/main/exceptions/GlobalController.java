package com.cg.spring.main.exceptions;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalController {

	@ExceptionHandler(Exception.class)
	public String handleException(Model model, Exception exception) {
		String view = "error";
		model.addAttribute("error", exception.getMessage());
		return view;
	}

}
