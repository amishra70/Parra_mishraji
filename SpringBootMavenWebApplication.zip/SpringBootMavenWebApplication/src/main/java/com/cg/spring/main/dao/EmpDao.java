package com.cg.spring.main.dao;

import com.cg.spring.main.model.Employee;

public interface EmpDao {

	boolean check(Employee employee);

}
