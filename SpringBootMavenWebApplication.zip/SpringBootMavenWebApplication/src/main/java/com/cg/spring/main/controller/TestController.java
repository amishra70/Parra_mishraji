package com.cg.spring.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.spring.main.exceptions.NameAlreadyExists;
import com.cg.spring.main.model.Employee;
import com.cg.spring.main.service.EmpService;

@Controller
public class TestController {

	@Autowired
	EmpService service;

	@RequestMapping("/")
	public String showHomePage() {
		return "home";
	}

	@RequestMapping("/test")
	public String showRegisterPage(Model model) {
		model.addAttribute("employee", new Employee());
		return "register";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)

	public String processRegister(Model model, @ModelAttribute("employee") Employee employee) throws NameAlreadyExists {

		String view = "";
		boolean result = service.checkEmployee(employee);

		if (result == true) {
			throw new NameAlreadyExists("Name already present..");
		} else {
			view = "success";
			model.addAttribute("data", employee);
		}

		return view;
	}

	/*@ExceptionHandler(Exception.class)
	public String handleException(Model model, Exception exception) {
		String view = "error";
		model.addAttribute("error", exception.getMessage());
		return view;
	}
*/
}
