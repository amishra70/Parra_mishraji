package com.cg.spring.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.main.dao.EmpDao;
import com.cg.spring.main.model.Employee;

@Service
public class EmpServiceImpl implements EmpService {

	@Autowired
	EmpDao dao;

	@Override
	public boolean checkEmployee(Employee employee) {
		return dao.check(employee);
	}

}
