package com.cg.spring.main.service;

import com.cg.spring.main.model.Employee;

public interface EmpService {

	boolean checkEmployee(Employee employee);

}
