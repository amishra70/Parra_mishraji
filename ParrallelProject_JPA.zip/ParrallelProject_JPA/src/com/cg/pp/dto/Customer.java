package com.cg.pp.dto;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Customer {
	@Id
	private long accountNo;
	private String custName;
	private String openingBalance;
	private String mobNo;
	private String adhrCard;
	AccountType accountType ;
	private String password;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public AccountType getAccountType() {
		return accountType;
	}
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}
	public Customer(int accountNo, String custName, String openingBalance,
			String mobNo, String adhrCard, AccountType accountType,
			String password) {
		super();
		this.accountNo = accountNo;
		this.custName = custName;
		this.openingBalance = openingBalance;
		this.mobNo = mobNo;
		this.adhrCard = adhrCard;
		this.accountType = accountType;
		this.password = password;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(String openingBalance) {
		this.openingBalance = openingBalance;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public String getAdhrCard() {
		return adhrCard;
	}
	public void setAdhrCard(String adhrCard) {
		this.adhrCard = adhrCard;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + accountNo + ", custName=" + custName
				+ ", openingBalance=" + openingBalance + ", mobNo=" + mobNo
				+ ", adhrCard=" + adhrCard + "]"+password;
	}

	
}
