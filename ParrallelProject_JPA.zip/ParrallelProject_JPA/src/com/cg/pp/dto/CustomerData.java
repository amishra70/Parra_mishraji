package com.cg.pp.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CustomerData {
	@Id @GeneratedValue
	private int id;
	private long accountNo;
	private double transaction;
	private double balance;
	private TransactionType transType;
	private String comment;
	public CustomerData(long accountNo, double transaction, double balance,
			TransactionType transType, String comment) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.transaction = transaction;
		this.transType = transType;
		this.comment = comment;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getTransaction() {
		return transaction;
	}
	public void setTransaction(double transaction) {
		this.transaction = transaction;
	}
	public TransactionType getTransType() {
		return transType;
	}
	public void setTransType(TransactionType transType) {
		this.transType = transType;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	@Override
	public String toString() {
		return "Account No.=" + accountNo+ ", Balance="
				+ balance + ", Transaction=" + transaction  + ", Transaction Type=" + comment + "]";
	}
	

	
}
