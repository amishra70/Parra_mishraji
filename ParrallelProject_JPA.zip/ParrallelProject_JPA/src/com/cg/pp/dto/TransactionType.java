package com.cg.pp.dto;

public enum TransactionType {
	Withdrawl,Fund,Deposit;
}
