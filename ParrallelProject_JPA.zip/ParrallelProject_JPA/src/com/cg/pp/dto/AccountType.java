package com.cg.pp.dto;

public enum AccountType {
Saving,Current
}
