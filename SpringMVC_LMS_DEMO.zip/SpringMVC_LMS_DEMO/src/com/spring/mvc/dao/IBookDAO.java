package com.spring.mvc.dao;

import java.util.List;

import com.spring.mvc.model.Book;

public interface IBookDAO {

	void insertBook(Book book);

	List<Book> getAllBooks();

	Book getBookDetails(int id);

	void updateBookData(Book book);

}
