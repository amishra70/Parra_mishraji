package com.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.mvc.dao.IBookDAO;
import com.spring.mvc.model.Book;

@Service
@Transactional
public class BookServiceImpl implements IBookService {

	@Autowired
	IBookDAO dao;

	@Override
	public void insertBook(Book book) {
		dao.insertBook(book);

	}

	@Override
	public List<Book> getAllBooks() {
		return dao.getAllBooks();
	}

	@Override
	public Book getBookDetails(int id) {
		return dao.getBookDetails(id);
	}

	@Override
	public void updateBookData(Book book) {
		dao.updateBookData(book);

	}

}
