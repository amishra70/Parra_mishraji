package com.spring.mvc.service;

import java.util.List;

import com.spring.mvc.model.Book;

public interface IBookService {

	void insertBook(Book book);

	List<Book> getAllBooks();

	Book getBookDetails(int id);

	void updateBookData(Book book);

}
