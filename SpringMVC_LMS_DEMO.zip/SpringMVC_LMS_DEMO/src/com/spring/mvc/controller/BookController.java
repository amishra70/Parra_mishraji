package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.mvc.model.Book;
import com.spring.mvc.service.IBookService;

@Controller
public class BookController {

	@Autowired
	IBookService service;

	@RequestMapping("/")
	public String showIndex() {
		String view = "index";
		return view;
	}

	@RequestMapping(value = "/bookinsert")
	public String showBookRegisterPage(Model model, HttpServletRequest request) {
		String view = "bookRegister";

		List<String> list = new ArrayList<>();
		list.add("comedy");
		list.add("action");
		list.add("suspense");
		list.add("horror");
		list.add("fiction");

		ServletContext context = request.getServletContext();
		context.setAttribute("categories", list);

		model.addAttribute("book", new Book());

		return view;
	}

	@RequestMapping(value = "/insertBook", method = RequestMethod.POST)
	public String addBook(Model model, @Valid @ModelAttribute("book") Book book, BindingResult result) {

		String view = "";

		// validator.validate(book, result);

		if (result.hasErrors()) {
			view = "bookRegister";
		} else {
			service.insertBook(book);
			model.addAttribute("msg", "Book inserted");
			view = "bookSuccess";
		}
		return view;
	}

	@RequestMapping(value = "/selectAll", method = RequestMethod.GET)
	public String getAllBooks(Model model) {

		String view = "";
		List<Book> list = service.getAllBooks();

		if (list.size() > 0) {
			view = "bookList";
			model.addAttribute("books", list);
		} else {
			model.addAttribute("error", "no books present");
			// view = "redirect:index";
			view = "fail";
		}
		return view;
	}

	@RequestMapping(value = "/updatebook/{id}", method = RequestMethod.GET)
	public String updateBook(@PathVariable("id") int id, Model model) {

		String view = "";
		Book book = service.getBookDetails(id);

		if (book != null) {
			model.addAttribute("book", book);
			model.addAttribute("bookBind", new Book());
			view = "showBookData";
		} else {
			model.addAttribute("message", "no book present with the given " + id);
			view = "showMsg";
		}
		return view;
	}

	@RequestMapping(value = "/updatebook/updateBookData", method = RequestMethod.POST)
	public String updateBookDetails(Model model, @ModelAttribute("bookBind") Book book) {

		String view = "updateSuccess";
		service.updateBookData(book);
		model.addAttribute("bookSuccess", "Book Updated with the given id: " + book.getId());
		return view;
	}
}
