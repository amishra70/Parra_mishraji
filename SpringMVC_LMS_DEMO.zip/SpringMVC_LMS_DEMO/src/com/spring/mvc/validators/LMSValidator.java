package com.spring.mvc.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.spring.mvc.model.Book;

public class LMSValidator implements Validator {

	@Override
	public boolean supports(Class<?> class1) {
		return Book.class.isAssignableFrom(class1);
	}

	@Override
	public void validate(Object object, Errors errors) {

		ValidationUtils.rejectIfEmpty(errors, "name", "error.name.empty");
		ValidationUtils.rejectIfEmpty(errors, "author", "error.author.empty");
		ValidationUtils.rejectIfEmpty(errors, "cost", "error.cost.empty");
		ValidationUtils.rejectIfEmpty(errors, "category", "error.category.empty");
	}

}
